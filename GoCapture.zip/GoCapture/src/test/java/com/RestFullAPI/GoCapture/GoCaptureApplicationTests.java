package com.RestFullAPI.GoCapture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoCaptureApplicationTests {

	@Test
	void contextLoads() {
	}

}
